// const images = {
//     logo: require("../assets/Decore.png ").default,
//     banner: require("../assets/Image.png").default,
//     profile: require("../../public/assets/profile.png").default,
//   };
  
//   export default images;
  
  import Decore from "@/assets/Decore.png";
import Imagenew from "@/assets/Image.png";
import profile from "@/assets/profile.png";

export const images = { Decore, Imagenew, };
