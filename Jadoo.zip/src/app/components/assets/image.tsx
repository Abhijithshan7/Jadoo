  
import Decore from "@/assets/Decore.png";
import Imagenew from "@/assets/Image.png";

export const images = { Decore, Imagenew, };
